var total;
var currentPage = 1;
var pageSize=20;
var rootUrl = "http://120.55.164.189:8081";
var selecttype="/selectParentFindChild";
var childlist;
var id = new Array();

function init(page, num) {
        currentPage = page;
        total = num;
        changePage(currentPage);
}

function setCurrentPage(page) {
    if (page > total || page < 1) {
        return;
    }
    currentPage = parseInt(page);
    console.log(currentPage);
}

function changePage(page) {
    let pageArr = [], light;
    console.log(page);
    if (page > total || page < 1) {
        return false;
    }
    page = parseInt(page);
    if (page > total - 5) {
        light = 8 - (total - page);
        pageArr = [1, "...", total - 6, total - 5, total - 4, total - 3, total - 2, total - 1, total];
    } else if (page < 6) {
        light = page - 1;
        pageArr = [1, 2, 3, 4, 5, 6, 7, '...', total];
    } else {
        light = 4;
        pageArr = [1, '...', page - 2, page - 1, page, page + 1, page + 2, '...', total];
    }
    console.log(pageArr);
    renderPage(pageArr, light);
    return true;
}

function renderPage(pageArr, light) {
    for (let i = 0; i < pageArr.length; i++) {
        $('.list-page').eq(i).text(pageArr[i]);
        if (pageArr[i] === '...') {
            $('.list-page').eq(i).css('border', 'none');
        } else if (i === 1 || i === pageArr.length - 2) {
            $('.list-page').eq(i).css('border', '1px solid #ccc');
        }
        $('.list-page').css('borderColor', '#ccc').css('color', '#000').css('background-color', '#fff');
        $('.list-page').eq(light).css('color', '#fff').css('background-color', '#555');

    }
}
/**
 * 分页
 */
$(document).ready(function() {
    $("#list").on('click', 'li', function () {
        switch ($(this).text()) {
            case '...': {
                break;
            }
            case'上一页': {
                setCurrentPage(currentPage - 1);
                getData();
                break;
            }
            case'下一页': {
                console.log("下一页");
                setCurrentPage(currentPage + 1);
                getData();
                break;
            }
            default: {
                setCurrentPage($(this).text());
                getData();
                break;
            }

        }
    });
});
// 判断登录状态
function judge() {
    //localStorage.getItem("emailAddr");
    let ema = localStorage.getItem("emailAddr");
    if (ema != null) {
        $("#log").hide();
    }
}
//清除
function signout() {
    localStorage.clear();
}
//提醒登录
function foo() {
    let ema = localStorage.getItem("emailAddr");
    if (ema == null) {
        alert("您未登录！请先登录！");
        window.event.returnValue = false;
    }
}

function search() {
    currentPage=1;//第一页
    getData();
}

function getData() {
    var name = $("#childname").val();
    var province = $("#province2 option:selected").val();
    //alert(province);
    if (province == "选择丢失省份") {
        province = null;
    }
    var city = $("#city2 option:selected").val();
    if (city == "请选择市") {
        city = null;
    }
    var district = $("#area2 option:selected").val();
    if (district == "请选择区") {
        district = null;
    }
    var detail = $("#childkey").val();
    var gender = $("#gender2").val();
    selecttype = $("#type").val();
    $.ajax({
            type: "GET", //请求方式
            url: rootUrl+selecttype,
            dataType: "json", //数据，json字符串
            async: false,
            data: {
                "name": name,
                "missingAddress.province": province,
                "missingAddress.city": city,
                "missingAddress.district": district,
                "detail": detail,
                "gender": gender,
                "pageNumber": currentPage,
                "pageSize": pageSize
            },
            //请求成功
            success: function (result) {
                console.log(result);
                childlist = result;
                if (result.code == 0) { // 查询成功
                    let totalPage=result.data[0];
                    init(currentPage,totalPage);
                    changePage(currentPage);
                    var j = 0;
                    var html2 = ""; //用一个变量来存储json中的数据
                    for (j = 0; j < result.data[1].content.length; j++) {
                        html2 += "<div class='child' onclick='gotodetails(" + j + ")'>" +
                            "<img src='" + result.data[1].content[j].photo + "'/ ></a>" +
                            "<li>" + result.data[1].content[j].name + "," + result.data[1].content[j].gender + "</li>" +
                            "<li>" + result.data[1].content[j].missingAddress.province + result.data[1].content[0].missingAddress.city + "</li>" +
                            "<li>" + result.data[1].content[j].detail + "</li>" +
                            "</div>";
                    }
                    document.getElementById("childbox").innerHTML = html2;
                } else if (result.code == 1) { // 登录失败
                    alert(result.message);
                }
            },
            //请求失败，包含具体的错误信息
            error: function (e) {
                alert("请求失败！");
            }
        });

}

function gotodetails(childid) {
    // alert(childid + childlist.data[1].content[childid].name);
    url = "detail.html?cname=" + childlist.data[1].content[childid].name +
        "&photo=" + childlist.data[1].content[childid].photo +
        "&gender=" + childlist.data[1].content[childid].gender +
        "&addr=" + childlist.data[1].content[childid].missingAddress.province + childlist.data[1].content[childid].missingAddress.city +
        "&detail=" + childlist.data[1].content[childid].detail +
        "&id=" +childlist.data[1].content[childid].id;
    //此处拼接内容
    window.location.href = url;
}



