
function judge() {
    //localStorage.getItem("emailAddr");
    let ema = localStorage.getItem("emailAddr");
    if (ema != null) {
        $("#log").hide();
    }else {
        alert("您未登录！请先登录！");
        window.location.href = "login.html";
    }

}
function judgeless() {
    //localStorage.getItem("emailAddr");
    let ema = localStorage.getItem("emailAddr");
    if (ema != null) {
        $("#log").hide();
    }
}
function signout() {
    localStorage.clear();
    window.location.href = "login.html";
}


function foo() {
    let ema = localStorage.getItem("emailAddr");
    if (ema == null) {
        alert("您未登录！请先登录！");
        window.event.returnValue = false;
    }
}