﻿var id1;
let rootUrl = "http://120.55.164.189:8081";
$(document).ready(function () {
    id1 = $.query.get("id");
    getData1();
});

function getData1() {
    $.ajax({
        type: "GET", //请求方式
        url: rootUrl+"/getReleaseById",
        dataType: "json", //数据，json字符串
        async: false,
        data: {
            "id":id1
        },
        //请求成功
        success: function (result) {


            if (result.code ===0) { // 查询成功
                console.log(result);
                document.getElementById('childimg').src = result.data[0].photo;
                $("#childName").text( "姓名：    "+ result.data[0].name);
                $("#childGender").text("性别:    "+ result.data[0].gender);
                $("#childBirthday").text("生日：    " + result.data[0].birthday);
                let homeAddress="";
                let missingAddress="";
                try{
                    homeAddress+=result.data[0].homeAddress.province+",";
                    homeAddress+=result.data[0].homeAddress.city+",";
                    homeAddress+=result.data[0].homeAddress.district;
                }catch (e) {
                    console.log("homeAddress不完全")
                }
                $("#childHomeAddr").text(" 出生地点：  " +homeAddress);
                try{
                    missingAddress+=result.data[0].missingAddress.province+",";
                    missingAddress+=result.data[0].missingAddress.city+",";
                    missingAddress+=result.data[0].missingAddress.district;
                }catch (e) {
                    console.log("MissingAddress不完全")
                }
                $("#childMissingAddr").text("走失地点：  " + missingAddress);
                $("#childDetail").text("其他信息：  "+result.data[0].detail);
            } else if (result.code ===1) { // 登录失败
                alert(result.message);
            }
        },
        //请求失败，包含具体的错误信息
        error: function (e) {
            alert("请求失败！");
        }
    });
}

function contactUser() {
    var url5 = "contactuser.html?id=" + id1;
    window.location.href = url5;
}

function match () {
    let searchFaceByIdUrl = rootUrl + "/searchFaceById";
    //alert(id1);
    $.ajax({
        type: "POST", //请求方式
        url: searchFaceByIdUrl,
        dataType: "json", //数据，json字符串
        //  processData: false, // 不处理数据
        //  contentType: false, // 不设置内容类型
        data:{
            "id":id1
        },
        //请求成功
        success: function (result) {
            console.log(result);
            if (result.code == 211) { // success
               // alert("1111111");
                console.log(result);
                matchObject = result;
                var url4 = "matchobject2.html?length=" + matchObject.data[0].length;
                var i = 0;
                for (i; i < matchObject.data[0].length; i++) {
                    url4 = url4 + "&id" + i + "=" + matchObject.data[0][i].id;
                }
                alert("匹配成功！");
                window.location.href = url4;

            }else if(result.code==212){
                //alert("222222222");
                console.log(result);
                matchObject = result;
                var url4 = "matchobject1.html?length=" + matchObject.data[0].length;
                var i = 0;
                for (i; i < matchObject.data[0].length; i++) {
                    url4 = url4 + "&id" + i + "=" + matchObject.data[0][i].id;
                }
                alert("匹配成功！");
                window.location.href = url4;

            }else  if(result.code==213){
               // alert("33333333");
                console.log(result);
                matchObject = result;
                var url4 = "matchobject.html?length=" + matchObject.data[0].length;
                var i = 0;
                for (i; i < matchObject.data[0].length; i++) {
                    url4 = url4 + "&id" + i + "=" + matchObject.data[0][i].id;
                }
                alert("匹配成功！");
                window.location.href = url4;
            }
            else { //fail

                alert(result.message);
            }
        },
        //请求失败，包含具体的错误信息
        error: function (e) {
            // alert("333333");
            alert(e.message);
        }
    });
}