﻿var rootUrl = "http://120.55.164.189:8081";
var search1Url = rootUrl + "/selectLatestChild";
var childlist;
var province="";

$(document).ready(function() {
    $("#list-provinces").on('click', 'li',function () {
        console.log($(this).text());
        switch ($(this).text()) {
            case "全部": {
                province="";
                load();
                break;
            }
            case"贵州省": {
                province="贵州省";
                load();
                break;
            }
            case"福建省": {
                province="福建省";
                load();
                break;
            }
            case "广东省":{
                province="广东省";
                console.log(province);
                load();
                break;
            }
            case "四川省":{
                province='四川省';
                load();
                break;
            }
            default: {
                console.log("default");
                load();
                break;
            }

        }
    });
});

function load() {
    $.ajax({
        type: "GET", //请求方式
        url: search1Url,
        dataType: "json", //数据，json字符串
        async: false,
        data: {
            "pageNum": "1",
            "size": "6",
            "province":province
        },
        //请求成功
        success: function (result) {
            childlist = result;
            // alert(result.data[1].content[0].name);
            if (result.code === 0) { // 查询成功
                console.log(result.data[1]);
                var j = 0;
                var html2 = ""; //用一个变量来存储json中的数据
                for (j = 0; j < result.data[1].content.length; j++) {
                    html2 += "<div class=\"col-lg-4 col-sm-4 col-md-6 isotopeSelector \" >" +
                        "<div class=\"portfolio-box zoom-effect\">" +
                        "<img src='" + result.data[1].content[j].photo + "' alt=''>" +
                        "<div class=\"portfolio-box-caption\">" +
                        "<div class=\"portfolio-box-caption-content\">" +
                        "<div class=\"project-name\">" + result.data[1].content[j].name +
                        "</div>" +
                        "<div class=\"project-social\">" + result.data[1].content[j].gender +
                        "</div>" +
                        "<div class=\"project-social\">" +
                        "<ul class=\"list-inline\">" +
                        "<li ><a onclick='gotodetails(" + j + ")'>" + "<i class=\"fa fa-link\">" + "</i>" + "</a></i>" +
                        "<li>" +
                        "<a href='" + result.data[1].content[j].photo + "' data-lightbox=\"example-set\" data-title=\"Click the right half of the image to move forward.\">" +
                        "<i class=\"fa fa-search\">" + "</i></a></li></ul></div></div></div></div></div>";
                }
                document.getElementById("latest").innerHTML = html2;
            } else if (result.code ===1) { // 登录失败
                alert(result.message);
            }
        },
        //请求失败，包含具体的错误信息
        error: function (e) {
            alert("请求失败！");
        }
    });
};


function gotodetails(childid) {
    //alert(childid + childlist.data[1].content[childid].name);
    url = "detail.html?id=" + childlist.data[1].content[childid].id;//此处拼接内容
    window.location.href = url;

}