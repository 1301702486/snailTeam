// pages/releaseList/releaseList.js
var app = getApp();
const rootUrl = app.globalData.rootUrl;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    emailAddr: null,
    cfp: null,
    pfc: null,
    smcList: [],
    showCfp: false,
    showPfc: false,
    showSmc: false
  },

  loadImageError: function (event) {
    console.log("图片加载失败");
    console.log(event.detail);
  },

  imageLoadSuccess: function (event) {
    console.log("图片加载成功");
    console.log(event.detail);
  },

  goToDetail: function () {
    wx.navigateTo({
      url: '../releaseDetail/releaseDetail',
      fail: function (e) {
        console.log("跳转失败");
        console.log(e);
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */

  goTop: function (e) {  // 一键回到顶部
    if (wx.pageScrollTo) {
      wx.pageScrollTo({
        scrollTop: 0
      })
    } else {
      wx.showModal({
        title: '提示',
        content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
      })
    }
  },
  onShow: function () {
    let that = this;
    wx.getStorage({
      key: 'emailAddr',
      success: function (res) {
        that.setData({
          emailAddr: res.data
        });
        console.log("请求成功 " + that.data.emailAddr);
        that.getCfpRelease();
        that.getPfcRelease();
        that.getSmcRelease();
      },
      fail: function () {
        console.log("getStorage请求失败--用户未登录");
        wx.showModal({
          title: '请先登录！',
          content: ' ',
          success: function (res) {
            if (res.confirm || res.cancel) {
              wx.redirectTo({
                url: '../login/login',
                success: function (res) {
                  console.log("重定向成功");
                  console.log(res);
                }
              });
            }
          },
          fail: function (res) {
            console.log("请求失败");
            console.log(res);
          }
        });
      }
    });
  },

  getCfpRelease: function () {
    let that = this;
    wx.request({
      url: rootUrl + "/getCfpRelease",
      data: {
        "emailAddr": that.data.emailAddr
      },
      dataType: "json",
      header: {
        "content-type": "application/x-www-form-urlencoded"
      },
      method: "GET",
      success: function (result) {
        console.log("请求成功");
        console.log(result);
        if (result.data.data != null) {
          that.setData({
            cfp: result.data.data[0],
            showCfp: true
          });
        } else {
          that.setData({
            showCfp: false
          });
        }
      },
      fail: function (result) {
        console.log("请求失败");
        console.log(result);
      }
    });
  },

  getPfcRelease: function () {
    let that = this;
    wx.request({
      url: rootUrl + "/getPfcRelease",
      data: {
        "emailAddr": that.data.emailAddr
      },
      dataType: "json",
      header: {
        "content-type": "application/x-www-form-urlencoded"
      },
      method: "GET",
      success: function (result) {
        console.log("请求成功");
        console.log(result);
        if (result.data.data != null) {
          that.setData({
            pfc: result.data.data[0],
            showPfc: true
          });
        } else {
          that.setData({
            showPfc: false
          });
        }
      },
      fail: function (result) {
        console.log("请求失败");
        console.log(result);
      }
    });
  },

  getSmcRelease: function () {
    let that = this;
    wx.request({
      url: rootUrl + "/getSmcRelease",
      data: {
        "emailAddr": that.data.emailAddr
      },
      dataType: "json",
      header: {
        "content-type": "application/x-www-form-urlencoded"
      },
      method: "GET",
      success: function (result) {
        console.log("请求成功");
        console.log(result);
        if (result.data.data != null) {
          that.setData({
            smcList: result.data.data[0],
            showSmc: true
          });
        } else {
          that.setData({
            showSmc: false
          });
        }
      },
      fail: function (result) {
        console.log("请求失败");
        console.log(result);
      }
    });
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})