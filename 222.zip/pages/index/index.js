//index.js
//获取应用实例
const app = getApp()
var pageNum = 1
var province = ""
Page({
  data: {
    imgUrls: [
      '../../images/555.jpg',
      '../../images/666.jpg',
      '../../images/777.jpg'
    ],
    indicatorDots: true,
    autoplay: true,
    interval: 3000,
    duration: 500,
    color: "#FFA500",
    color2: "#FFFAF0",
    floorstatus: true,
    flag: false,
    preventflag: true,
    province: "",
    children: [],
    genders: ["不限", "男", "女"],
    index: 0,
    region: ["全部", "全部", "全部"],
    customItem: '全部',
    database: ["家寻宝贝", "宝贝寻家", "流浪儿童"],
    animationAddressMenu: {},
    addressMenuIsShow: false,
    value: [0, 0, 0],
    name: '',
    gender: '',
    province: '',
    city: '',
    district: '',

    Hei: "",
    actIndex: 'first'



  },
  imgH: function (e) {
    var winWid = wx.getSystemInfoSync().windowWidth; //获取当前屏幕的宽度
    var imgh = e.detail.height;　　　　　　　　　　　　　　　　 //图片高度
    var imgw = e.detail.width;
    var swiperH = winWid * imgh / imgw + "px";
    this.setData({
      Hei: swiperH　　　　　　　　 //设置高度
    })
  },

  changeMenu: function (e) {
    this.setData({
      actIndex: e.currentTarget.id,
    })
    if (this.data.actIndex == 'first') {
      this.setData({
        flag: false,
        preventflag: true,
      })

      pageNum = 1;

      var that = this
      const requestTask = wx.request({
        url: "http://120.55.164.189:8081/selectLatestChild",
        data: {
          "pageNum": pageNum,
          "size": 20,
          "province": province
        },
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        method: 'GET',
        dataType: 'json',
        responseType: 'text',
        success: function (res) {
          var childlist = res.data.data[1].content
          console.log(childlist)
          that.setData({
            children: res.data.data[1].content
          })
        },
        fail: function (res) {

        }
      })

    } else if (this.data.actIndex == 'second') {
      this.showDialogBtn();

    } else if (this.data.actIndex == 'third') {
      this.setData({
        flag: true,
        preventflag: false,
      })


    }

  },
  load1: function () {
    pageNum++
    var that = this
    const requestTask = wx.request({
      url: "http://120.55.164.189:8081/selectLatestChild",
      data: {
        "pageNum": pageNum,
        "size": 20,
        "province": province
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: 'GET',
      dataType: 'json',
      responseType: 'text',
      success: function (res) {
        var childlist = res.data.data[1].content
        console.log(childlist)
        that.setData({
          children: res.data.data[1].content
        })
      },
      fail: function (res) {

      }
    })


  },
  showDialogBtn: function () {
    this.setData({
      showModal: true
    })
  },
  //隐藏筛选弹窗
  hideModal: function () {
    this.setData({
      showModal: false
    });
  },
  preventTouchMove: function () { },
  /**
   * 对话框取消按钮点击事件
   */
  onCancel: function () {
    this.hideModal();
  },
  /**
   * 对话框确认按钮点击事件
   */
  onConfirm: function () {
    this.hideModal();
    var route;
    switch (this.data.database[this.data.index2]) {
      case "家寻宝贝":
        route = "/selectParentFindChild";
        break;
      case "宝贝寻家":
        route = "/selectChildFindParent";
        break;
      case "流浪儿童":
        route = "/selectSuspectedMissingChild";
      default:
        route = "/selectParentFindChild";
    }
    if (this.data.gender == "不限") {
      this.setData({
        gender: ""
      })
    }
    if (this.data.province == '全部') {
      this.setData({ province: '' })
    }
    if (this.data.city == '全部') {
      this.setData({ city: '' })
    }
    if (this.data.district == '全部') {
      this.setData({ district: '' })
    }
    /**
     * 筛选请求
     */
    var that = this;
    const requestTask = wx.request({
      route: "",
      url: "http://120.55.164.189:8081/" + route,
      data: {
        "pageNumber": pageNum,
        "pageSize": 20,
        "name": this.data.name,
        "gender": this.data.gender,
        "missingAddress.province": this.data.province,
        "missingAddress.city": this.data.city,
        "missingAddress.district": this.data.district
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: 'GET',
      dataType: 'json',
      responseType: 'text',
      success: function (res) {
        console.log(pageNum)
        console.log(res.data.data[1].content)
        that.setData({
          children: res.data.data[1].content
        })
      },
      fail: function (res) {

      }
    })

  },
  //获取姓名
  nameChange: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  //性别选择器
  bindPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    var that = this;
    let index = e.detail.value;
    this.setData({
      gender: that.data.genders[index]
    })
  },
  //地区选择
  bindRegionChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    var region = e.detail.value
    this.setData({
      region: e.detail.value,
      province: region[0],
      city: region[1],
      district: region[2]
    })
  },
  //数据库选择
  bindDatabaseChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index2: e.detail.value
    })
  },
  goTop: function (e) {  // 一键回到顶部
    if (wx.pageScrollTo) {
      wx.pageScrollTo({
        scrollTop: 0
      })
    } else {
      wx.showModal({
        title: '提示',
        content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
      })
    }
  },

  onLoad: function () {
    wx.showShareMenu({
      withShareTicket: true
    })


    var that = this
    const requestTask = wx.request({
      url: "http://120.55.164.189:8081/selectLatestChild",
      data: {
        "pageNum": pageNum,
        "size": 20,
        "province": province
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: 'GET',
      dataType: 'json',
      responseType: 'text',
      success: function (res) {
        var childlist = res.data.data[1].content
        console.log(childlist)
        that.setData({
          children: res.data.data[1].content
        })
      },
      fail: function (res) {

      }
    })
  }
})