// pages/releaseDetail/releaseDetail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    showDetail: true,
    showMatchResult: false,
    children: null,
    detail: null
  },
  
  viewMatchResult: function () {
    let that = this;
    wx.request({
      url: 'http://120.55.164.189:8081/searchFaceById',
      data: {
        id: that.data.detail.id
      },
      method: "POST",
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (result) {
        if (result.data.data != null) {
          that.setData({
            children: result.data.data[0],
            showMatchResult: true,
            showDetail: false
          });
        } else {
          wx.showToast({
            title: result.data.message,
            icon: "none",
            duration: 2000
          });
        }
      },
      fail: function (result) {
        console.log("失败");
        console.log(result.data);
      }
    })
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    // wx.showToast({
    //   title: '加载中',
    //   icon:'loading'
    // });
    console.log(options)
    const requestTask = wx.request({
      url: "http://120.55.164.189:8081/getReleaseById",
      data: {
        "id": options.id
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: 'GET',
      dataType: 'json',
      responseType: 'text',
      success: function (res) {
        console.log(res.data.data[0])
        that.setData({
          detail: res.data.data[0]
        })
      },
      fail: function (res) {
        console.log("失败")
      }
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})