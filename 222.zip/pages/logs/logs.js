//logs.js
const util = require('../../utils/util.js')

Page({
  data: {
    imgUrls: [
      '../../images/555.jpg',
      '../../images/666.jpg',
      '../../images/777.jpg'
    ],
    indicatorDots: true,
    autoplay: true,
    interval: 3000,
    duration: 500,
    color: "#FFA500",
    color2: "#FFFAF0",
    floorstatus: true,
    flag: false,
    preventflag: true,


    Hei: "",
    actIndex: 'first'



  },
  imgH: function(e) {
    var winWid = wx.getSystemInfoSync().windowWidth; //获取当前屏幕的宽度
    var imgh = e.detail.height;　　　　　　　　　　　　　　　　 //图片高度
    var imgw = e.detail.width;
    var swiperH = winWid * imgh / imgw + "px";
    this.setData({
      Hei: swiperH　　　　　　　　 //设置高度
    })
  },

  gotopfchild: function() {
    wx.navigateTo({
      url: '/pages/pfchild/pfchild',
    })
  },

  gotocfparent: function() {
    wx.navigateTo({
      url: '/pages/cfparent/cfparent',
    })
  },

  gotovachild: function() {
    wx.navigateTo({
      url: '/pages/vachild/vachild',
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    let that = this;
    wx.getStorage({
      key: 'emailAddr',
      success: function(res) {
        console.log("请求成功 " + that.data.emailAddr);
      },
      fail: function() {
        console.log("getStorage请求失败--用户未登录");
        wx.showModal({
          title: '请先登录！',
          content: ' ',
          success: function(res) {
            if (res.confirm || res.cancel) {
              wx.redirectTo({
                url: '../login/login',
                success: function(res) {
                  console.log("重定向成功");
                  console.log(res);
                }
              });
            }
          },
          fail: function(res) {
            console.log("请求失败");
            console.log(res);
          }
        });
      }
    });
  }
})