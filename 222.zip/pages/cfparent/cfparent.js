// pages/cfparent/cfparent.js
import {
  promisify
} from '../../utils/promise.util'
import {
  $init,
  $digest
} from '../../utils/common.util'

import '../../utils/util.js'

// const wxUploadFile = promisify(wx.uploadFile)

Page({

  data: {
    gender: [{
      name: '男',
      value: "男"
    },
    {
      name: '女',
      value: "女"
    }
    ],
    titleCount: 0,
    contentCount: 0,
    title: '',
    content: '',
    images: [],
    isShow: true,
    isShow1: false,
    children: [],
    hprovince: null,
    hcity: null,
    hdistrict: null
  },

  onLoad(options) {
    $init(this)
  },


  handleContentInput(e) {
    const value = e.detail.value
    this.data.content = value
    this.data.contentCount = value.length
    $digest(this)
  },


  removeImage(e) {
    const idx = e.target.dataset.idx
    this.data.images.splice(idx, 1)
    $digest(this)
  },

  handleImagePreview(e) {
    const idx = e.target.dataset.idx
    const images = this.data.images

    wx.previewImage({
      current: images[idx],
      urls: images,
    })
  },


  bindDateChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      date: e.detail.value
    })
  },
  bindDateChange1: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      date1: e.detail.value
    })
  },
  bindPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index: e.detail.value
    })
  },
  chooseImage(e) {
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: res => {
        const images = this.data.images.concat(res.tempFilePaths)
        this.data.images = images.length <= 1 ? images : images.slice(0, 1)
        $digest(this)
        const tempFilePaths = res.tempFilePaths
      }
    })
  },
  formSubmit: function (e) {
    let that = this;
    console.log(e.detail.value);
    var ema = wx.getStorageSync('emailAddr');
    if (e.detail.value.name.length == 0 || e.detail.value.name.length >= 8) {
      wx.showToast({
        title: '姓名不能为空或过长!',
        icon: 'loading',
        duration: 1500
      })
      setTimeout(function () {
        wx.hideToast()
      }, 2000)
    } else if (e.detail.value.gender.length == 0) {
      wx.showToast({
        title: '性别不能为空!',
        icon: 'loading',
        duration: 1500
      })
      setTimeout(function () {
        wx.hideToast()
      }, 2000)
    } else {
      wx.chooseImage({
        count: 1,
        sizeType: ['original', 'compressed'],
        sourceType: ['album', 'camera'],
        success: res => {
          const images = this.data.images.concat(res.tempFilePaths)
          this.data.images = images.length <= 1 ? images : images.slice(0, 1)
          $digest(this)
          const tempFilePaths = res.tempFilePaths

          wx.uploadFile({
            url: 'http:/120.55.164.189:8081/addChildFindParent',
            filePath: tempFilePaths[0],
            name: 'releasePhoto',
            method: "POST",
            header: {
              "Content-Type": "multipart/form-data"
            },
            formData: {
              "emailAddr": ema,
              "name": e.detail.value.name,
              "birthday": e.detail.value.birthday,
              "missingDate": e.detail.value.missingDate,
              "gender": e.detail.value.gender,
              "missingAddress.province": e.detail.value.mprovince,
              "missingAddress.city": e.detail.value.mcity,
              "missingAddress.district": e.detail.value.mdistrict,
              "missingAddress.detail": e.detail.value.dmdetail,
              "homeAddress.province": e.detail.value.dhprovince,
              "homeAddress.city": e.detail.value.hcity,
              "homeAddress.district": e.detail.value.hdistrict,
              "homeAddress.detail": e.detail.value.hdetail,
              "detail": e.detail.value.detail,
            },
            success: function (res) {
              console.log(res.data);
              var str = res.data;
              str = str.replace(/\ufeff/g, "");
              var data = JSON.parse(str);
              console.log(data);
              if (data.code == 0) { // success
                // console.log("1111111");
                wx.showModal({
                  title: '提示',
                  content: '发布成功',
                  showCancel: true,
                 
                  confirmText: '确定',
                  confirmColor: '',
                  success: function(res) {},
                  fail: function(res) {},
                  complete: function(res) {},
                })
                var children;
                that.setData({
                  children: data.data[0],
                  isShow: false,
                  isShow1: true
                })
              }
            },
            fail: function (res) { //fail
              wx.showToast({
                title: '提交失败',
                icon: 'loading',
                duration: 1000
              })

            }
          })
        }
      })
    }


  },
  onShow: function () {
    let that = this;
    var latitude;
    var longitude;
    wx.getLocation({
      success: function (res) {
        latitude = res.latitude;
        longitude = res.longitude;
        wx.request({
          url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=',
          method: "GET",
          data: {
            "location": latitude + "," + longitude,
            "key": "WU4BZ-WADHQ-USO55-GU5UU-Z4B57-LYBKJ"
          },
          success: (res) => {
            console.log("请求成功");
            console.log(res);
            that.setData({
              hprovince: res.data.result.address_component.province,
              hcity: res.data.result.address_component.city,
              hdistrict: res.data.result.address_component.district
            });
          },
          fail: (res) => {
            console.log("请求失败");
          }
        });
      },
    });
  }

})