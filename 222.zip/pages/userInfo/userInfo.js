// pages/userInfo/userInfo.js
var app = getApp();
const rootUrl = app.globalData.rootUrl;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    windowHeight: null,
    windowWidth: null,
    emailAddr: null,
    password1: null,
    password2: null,
    showModal: false
  },

  changePassword: function () {
    this.setData({
      showModal: true
    });
  },
  /**
   * 获取用户输入信息
   */
  bindPass1: function (e) {
    this.setData({
      password1: e.detail.value
    });
  },
  bindPass2: function (e) {
    this.setData({
      password2: e.detail.value
    });
  },
  /**
   * 弹出框蒙层截断touchmove事件
   */
  preventTouchMove: function () { },
  /**
   * 隐藏模态对话框
   */
  hideModal: function () {
    this.setData({
      showModal: false
    });
  },
  /**
   * 取消修改密码
   */
  onCancel: function () {
    this.hideModal();
  },
  /**
   * 确认修改密码
   */
  onConfirm: function () {
    const pass1 = this.data.password1;
    const pass2 = this.data.password2;
    const email = this.data.emailAddr;
    if (pass1 != pass2) {
      wx.showToast({
        title: '两次密码输入不同',
        icon: "none",
        duration: 2000
      })
      return;
    }
    this.hideModal();
    const changePassUrl = rootUrl + "/changePassword?emailAddr=" + email + "&password=" + pass1;
    wx.request({
      url: changePassUrl,
      data: {
        "emailAddr": email,
        "password": pass1
      },
      header: {
        "content-type": "application/x-www-form-urlencoded"
      },
      method: "PUT",
      success: function (result) {
        console.log("修改密码成功");
        wx.showToast({
          title: '修改密码成功',
          icon: "none",
          duration: 2000
        })
        console.log(result);
      },
      fail: function (result) {
        console.log("修改密码失败");
        console.log(result);
      }
    })
  },

  /**
   * 退出登录
   */
  logout: function () {
    wx.showModal({
      title: '确定要退出登录？',
      content: ' ',
      success: function (res) {
        if (res.confirm) {
          wx.clearStorage();
          wx.reLaunch({
            url: '../index/index',
            success: function (res) {
              console.log("已登出");
              console.log(res);
            }
          });
        }
      },
      fail: function (res) {
        console.log("登出请求失败");
        console.log(res);
      }
    });

  },
  /**
   * 跳转到发布列表界面
   */
  toReleaseList: function () {
    wx.navigateTo({
      url: '../releaseList/releaseList',
      success: function (res) {
        console.log("重定向成功");
        console.log(res);
      }
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        })
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    let that = this;
    wx.getStorage({
      key: 'emailAddr',
      success: function (res) {
        that.setData({
          emailAddr: res.data
        });
        console.log("请求成功 " + that.data.emailAddr);
      },
      fail: function () {
        console.log("getStorage请求失败--用户未登录");
        wx.showModal({
          title: '请先登录！',
          content: ' ',
          success: function (res) {
            if (res.confirm || res.cancel) {
              wx.redirectTo({
                url: '../login/login',
                success: function (res) {
                  console.log("重定向成功");
                  console.log(res);
                }
              });
            }
          },
          fail: function (res) {
            console.log("请求失败");
            console.log(res);
          }
        });
      }
    });
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})