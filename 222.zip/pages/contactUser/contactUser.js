// pages/contactUser/contactUser.js
const rootUrl = getApp().globalData.rootUrl;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    emailAddr: null,
    userName: null,
    title: null,
    message: null,
    id: null
  },

  bindEmail: function(e) {
    this.setData({
      emailAddr: e.detail.value
    });
  },

  bindName: function(e) {
    this.setData({
      userName: e.detail.value
    });
  },

  bindTitle: function(e) {
    this.setData({
      title: e.detail.value
    });
  },

  bindMessage: function(e) {
    this.setData({
      message: e.detail.value
    });
  },

  sendMessage: function() {
    let ema = this.data.emailAddr;
    let releaseId = this.data.id;
    let name = this.data.userName;
    let content = this.data.message;
    let title = this.data.title;
    wx.request({
      url: rootUrl + "/contactUser",
      method: "POST",
      header: {
        "content-type": "application/x-www-form-urlencoded"
      },
      data: {
        "emailAddr": ema,
        "id": releaseId,
        "name": name,
        "contentStr": content,
        "title": title
      },
      success: function(e) {
        console.log("请求成功");
        console.log(e);
      },
      fail: function(e) {
        console.log("请求失败");
        console.log(e);
      }
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      id: options.id
    });
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    let that = this;
    wx.getStorage({
      key: 'emailAddr',
      success: function(res) {
        console.log("请求成功 " + that.data.emailAddr);
      },
      fail: function() {
        console.log("getStorage请求失败--用户未登录");
        wx.showModal({
          title: '请先登录！',
          content: ' ',
          success: function(res) {
            if (res.confirm || res.cancel) {
              wx.redirectTo({
                url: '../login/login',
                success: function(res) {
                  console.log("重定向成功");
                  console.log(res);
                }
              });
            }
          },
          fail: function(res) {
            console.log("请求失败");
            console.log(res);
          }
        });
      }
    });
  }
})