var app = getApp();
const rootUrl = app.globalData.rootUrl;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    windowHeight: null,
    windowWidth: null,
    emailAddr: null,
    password: null,
    code: 0,
    sentCode: 0
  },
  /**
   * 获取用户输入信息
   */
  bindEmail: function (e) {
    this.setData({
      emailAddr: e.detail.value
    });
  },
  bindPass: function (e) {
    this.setData({
      password: e.detail.value
    });
  },
  bindCode: function (e) {
    this.setData({
      code: e.detail.value
    });
  },
  /**
   * 发送验证码事件处理
   */
  sendCode: function () {
    const account = this.data.emailAddr;
    const registerUrl = rootUrl + "/sendCode";
    let that = this;

    // 判断账号是否为空
    if (null == account) {
      wx.showToast({
        title: "用户名不能为空",
        icon: "none",
        duration: 2000
      });
      return;
    }

    wx.request({
      header: {
        "content-type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      url: registerUrl,
      dataType: "json",
      data: {
        "emailAddr": account
      },
      success: function (result) {
        console.log("sentCode: " + result.data.data);
        that.setData({
          sentCode: result.data.data
        });
        wx.showToast({
          title: '验证码已发送',
          icon: "success",
          duration: 2000
        })
      },
      fail: function (result) {
        console.log(result);
      }
    });
  },
  /**
   * 注册事件处理
   */
  registerHandler: function () {
    const account = this.data.emailAddr;
    const password = this.data.password;
    const registerUrl = rootUrl + "/wxRegister";

    // 判断账号是否为空
    if ("" == account) {
      wx.showToast({
        title: "用户名不能为空",
        icon: "none",
        duration: 2000
      });
      return;
    }
    // 判断密码是否为空
    if (null == password) {
      wx.showToast({
        title: "密码不能为空",
        icon: "none",
        duration: 2000
      });
      return;
    }
    // 判断验证码是否正确
    if (this.data.code != this.data.sentCode || this.data.code == 0 || this.data.sendCode == 0) {
      wx.showToast({
        title: '验证码输入错误',
        icon: "none",
        duration: 2000
      });
      return;
    }
    wx.request({
      header: {
        "content-type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      url: registerUrl,
      dataType: "json",
      data: {
        "emailAddr": account,
        "password": password
      },
      success: function (result) {
        console.log(result);
        wx.showModal({
          title: '注册状态',
          content: '注册成功，请点击确定登录吧',
          success: function (res) {
            if (res.confirm) {
              // 点击确定后跳转登录页面并关闭当前页面
              wx.navigateBack({
                delta: 1
              });
            }
          }
        });
      },
      fail: function (result) {
        console.log("注册请求失败");
        console.log(result);
      }
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        })
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})