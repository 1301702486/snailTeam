var app = getApp();
const rootUrl = app.globalData.rootUrl;

Page({
  data: {
    windowHeight: null,
    windowWidth: null,
    emailAddr: null,
    password: null
  },
  onLoad: function () {
    let that = this;
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        })
      }
    });
  },
  /**
   * 获取用户输入信息
   */
  bindEmail: function (e) {
    this.setData({
      emailAddr: e.detail.value
    });
  },
  bindPass: function (e) {
    this.setData({
      password: e.detail.value
    });
  },
  /**
   * 跳转到注册界面
   */
  registerHandler: function () {
    wx.navigateTo({
      url: '../register/register',
    });
  },
  /**
   * 登录事件处理
   */
  loginHandler: function () {
    var account = this.data.emailAddr;
    var password = this.data.password;
    // 判断账号是否为空
    if (null == account) {
      wx.showToast({
        title: "用户名不能为空",
        icon: "none",
        duration: 2000
      });
      return;
    }
    // 判断密码是否为空
    if (null == password) {
      wx.showToast({
        title: "密码不能为空",
        icon: "none",
        duration: 2000
      });
      return;
    }
    //登录
    const registerUrl = rootUrl + "/login";
    wx.request({
      header: {
        "content-type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      url: registerUrl,
      dataType: "json",
      data: {
        "emailAddr": account,
        "password": password
      },
      success: function (result) {
        console.log(result);
        if (result.data.code === 0) {
          wx.setStorage({
            key: 'emailAddr',
            data: account,
            success: function () {
              console.log("邮箱保存成功 " + account);
            }
          });
          wx.setStorage({
            key: 'password',
            data: password,
            success: function () {
              console.log("密码保存成功 " + password);
            }
          });
          // 跳转到主页
          // wx.navigateTo({
          //   url: '../index/index',
          // });
          wx.showToast({
            title: '登录成功',
            duration: 2000
          })
          wx.switchTab({
            url: '/pages/index/index',
          });
        } else {
          wx.showToast({
            title: result.data.message,
            icon: "none",
            duration: 2000
          });
        }
      },
      fail: function (result) {
        console.log(result);
      }
    });
  }
});